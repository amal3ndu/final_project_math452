# TRELLO API documentation URL: https://developer.atlassian.com/cloud/trello/rest/api-group-boards/#api-boards-post

# This code sample uses the 'requests' library:
# http://docs.python-requests.org
import requests
import random

# defining some constants
URL = "https://api.trello.com/1"
ERROR, EXIT, CREATE_CARD = -1, 0, 1

color_list = [
    "lime", "pink", "black", "green_dark", "yellow_dark", "orange_dark",
    "red_dark", "purple_dark", "blue_dark", "sky_dark", "lime_dark",
    "pink_dark", "black_dark", "green_light", "yellow_light", "orange_light",
    "red_light", "purple_light", "blue_light", "sky_light", "lime_light",
    "pink_light", "black_light"
]


def get_user_choice(prompt, options):
    end_index = str(len(options) - 1)
    while True:
        print(prompt)
        for i, option in enumerate(options):
            print(f"{i}. {option}")

        choice = input("Enter the number of your choice [0-" + end_index + "]: ")
        if choice.isdigit() and 0 <= int(choice) < len(options):
            return int(choice)

        print("Invalid choice. Please select a valid option.")


def get_user_creds():
    api = tok = ''
    logged_in = False
    response = ''

    print("You can find your API Key and Token at the following link:"
          "\nhttps://trello.com/power-ups/admin/")
    input("Visit the link and set up your account, and then press enter to continue...")

    while not logged_in:
        api = input("Enter your Trello API key: ")
        tok = input("Enter your Trello token: ")

        url = f'{URL}/members/me?key={api}&token={tok}'
        response = requests.get(url)

        logged_in = True if response.status_code == 200 else print("Error: Invalid credentials")

    print("Logged in successfully, welcome\n-", response.json()['username'])
    return api, tok


def get_board_id(api, tok):
    url = f'{URL}/members/me/boards?key={api}&token={tok}'
    user_actions = ["<Exit>"]

    response = requests.get(url)

    if response.status_code == 200:
        boards = response.json()

        board_names = [board['name'] for board in boards]
        board_names = user_actions + board_names

        choice = get_user_choice("Select a board:", board_names)

        if choice < len(user_actions):
            return choice
        else:
            choice -= len(user_actions)
            print("Board Selected:", boards[choice]['name'])
            return boards[choice]['id']

    else:
        print("Error: Unable to retrieve boards -> ", response.status_code)
        return ERROR


def get_list_id(api, tok, board_id):
    lists_url = f'{URL}/boards/{board_id}/lists?key={api}&token={tok}'
    user_actions = ["<Exit>"]

    response = requests.get(lists_url)

    if response.status_code == 200:
        lists = response.json()

        list_names = [lst['name'] for lst in lists]
        user_choices = user_actions + list_names
        choice = get_user_choice("Select a list:", user_choices)

        if choice < len(user_actions):
            return choice
        else:
            choice -= len(user_actions)
            print("List Selected:", lists[choice]['name'])
            return lists[choice]['id']
    else:
        print("Error: Unable to retrieve lists ->", response.status_code)
        return ERROR


def get_card_id(api, tok, lst):
    url = f'{URL}/lists/{lst}/cards?key={api}&token={tok}'
    user_actions = ["<Exit>", "<Create New Card>"]

    response = requests.get(url)

    if response.status_code == 200:
        cards = response.json()
        card_names = [card['name'].lstrip() for card in cards]

        user_choices = user_actions + card_names

        choice = get_user_choice("Select an option:", user_choices)

        if choice < len(user_actions):
            return choice
        else:
            choice -= len(user_choices)
            card_id = cards[choice]['id']
            return card_id
    else:
        print("Error: Unable to retrieve cards -> ", response.status_code)
        return ERROR


def display_card(api, tok, card_id):
    url = f'{URL}/cards/{card_id}?key={api}&token={tok}'
    response = requests.get(url)

    if response.status_code == 200:
        print(response.json()['name'], ":", response.json()['desc'])
    else:
        print(response.status_code)
    input("Press enter to continue...")


def create_card(api, tok, board, lst):
    name = input("Enter the card name: ").strip()
    desc = input("Enter the card description: ").strip()
    labels = input("Enter the card label separated with commas [optional]: ").strip().lower()
    comment = input("Enter the card comment [optional]: ").strip()

    url = f'{URL}/cards?idList={lst}&key={api}&token={tok}&name={name}&desc={desc}&comments={comment}'

    response = requests.post(url)

    if response.status_code == 200:
        card_id = response.json()['id']
        print("Card created successfully")
        add_label(api, tok, board, card_id, labels) if len(labels) > 0 else print("No label detected")
        add_comment(api, tok, card_id, comment) if len(comment) > 0 else print("No comment detected")

    else:
        print("Error: Card creation unsuccessful ->", response.status_code)
        return ERROR


def add_label(api, tok, board_id, card_id, labels):
    label_names = labels.split(',')  # Split label names into a list
    label_names = [name.strip() for name in label_names if len(name)]

    get_labels_url = f'{URL}/boards/{board_id}/labels?key={api}&token={tok}'

    label_response = requests.get(get_labels_url)

    if label_response.status_code == 200:
        created_labels = label_response.json()
        created_label_names = [label['name'].lstrip().lower() for label in created_labels]

        for label_name in label_names:
            # if label exists, add it to the label ids
            if label_name in created_label_names:
                index = created_label_names.index(label_name)
                label_id = created_labels[index]['id']

                add_label_url = f'{URL}/cards/{card_id}/idLabels?key={api}&token={tok}&value={label_id}'

            # otherwise, let user know the label doesn't exist
            else:
                color = color_list[random.randint(0, len(color_list))]
                add_label_url = f'{URL}/cards/{card_id}/labels?key={api}&token={tok}&color={color}&name={label_name}'

            add_label_response = requests.post(add_label_url)

            if add_label_response.status_code == 200:
                print("Label added:", label_name)
            else:
                print("Error:", label_name, "unable to be added creation unsuccessful ->",
                      add_label_response.status_code)
    else:
        print("Error: Unable to pull labels unsuccessful ->", label_response.status_code)


def add_comment(api, tok, card_id, comment):
    create_comment_url = f'{URL}/cards/{card_id}/actions/comments?key={api}&token={tok}&text={comment}'
    create_comment_response = requests.post(create_comment_url)

    if create_comment_response.status_code != 200:
        print("Error: Comment unable to be added creation unsuccessful ->", create_comment_response.status_code)
    else:
        print("Comment added: ", comment)


def main():
    api_key, token = get_user_creds()
    logged_in = True
    board_id = list_id = None

    # main loop
    while logged_in:

        if board_id and list_id:
            card_id = get_card_id(api_key, token, list_id)

            if card_id == CREATE_CARD:
                create_card(api_key, token, board_id, list_id)
            elif card_id:
                display_card(api_key, token, card_id)
            else:
                list_id = None

        elif board_id:
            list_id = get_list_id(api_key, token, board_id)

            if list_id == EXIT:
                board_id = None
        else:
            board_id = get_board_id(api_key, token)

            if board_id == EXIT:
                logged_in = False
    print("Goodbye!")


if __name__ == "__main__":
    main()
