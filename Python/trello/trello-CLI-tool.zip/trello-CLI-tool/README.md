# Trello CLI Tool

A command-line interface (CLI) tool to interact with Trello, allowing users to authenticate, view their boards, and add cards to specific boards.

## Usage

1. Authenticate: Run the CLI tool and provide your API Key and Token to authenticate your Trello account.

2. View Boards: Once authenticated, you can view your Trello boards and select a board & associated list via index.

3. Add Card: After selecting a board, you can add a card by providing card details such as name, labels, and comments. Existing labels will be added, and new labels will be created.

## Authentication

The authentication process involves obtaining an access token from Trello through OAuth 1.0a. You can access your Trello API key and Token using the following link: https://trello.com/power-ups/admin/ 

## Example

```bash
python trello_cli.py

# Follow the authentication steps
# After authentication, you can view your boards and select one
# Then, provide card details to add a new card to the selected board
